"use strict";
$(document).ready(function()
{
    //Checks to see if the date entered is valid
    var isDate = function(text) 
    {
        if( ! /^[01]?\d\/[0-3]\d\/\d{4}$/.test(text) ) return false;
        
        var index1 = text.indexOf( "/" );
        var index2 = text.indexOf( "/", index1 + 1 );
        var month = parseInt( text.substring( 0, index1 ) );
        var day = parseInt( text.substring( index1 + 1, index2 ) );
        
        if( month < 1 || month > 12 ) 
        { 
            return false; 
        }
        //if( day > 31 ) { return false; }
        else {
            switch( month ) 
            {
                case 2:
                    if ( day > 28 ) 
                    { 
                        return false; 
                    } // doesn't handle leap year
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    if ( day > 30 ) 
                    { 
                        return false; 
                    }
                    break;
                default:
                    if ( day > 31 ) 
                    { 
                        return false; 
                    }
                    break;
            }
        }
        return true; 
    };
    
    //Runs on the click of the save button
    $( "#save" ).click(function() 
    {
        $("span").text("");   // clear any previous error messages
        var isValid = true;   // initialize isValid flag
        
        var email = $("#email").val();
        var phone = $("#phone").val();
        var zip = $("#zip").val();
        var dob = $("#dob").val();
		
        // initialize empty array here 
        var profile = new Array(4);
        
        // Add the email, phone, zip, and dob to the array.
        profile["email"] = email;
        profile["phone"] = phone;
        profile["zip"] = zip;
        profile["dob"] = dob;
		
        //checks all of the fields to make sure they are valid        
        if ( email === "" || 
                !email.match(/^[\w\.\-]+@[\w\.\-]+\.[a-zA-Z]+$/) ) 
        {
            isValid = false;
            $( "#email" ).next().text("Please enter a valid email.");
        }
        if ( phone === "" || !phone.match(/^\d{3}-\d{3}-\d{4}$/) ) 
        {
            isValid = false;
            $( "#phone" ).next().text(
                "Please enter a phone number in NNN-NNN-NNNN format.");
        }
        if ( zip === "" || !zip.match(/^\d{5}(-\d{4})?$/) ) 
        {
            isValid = false;
            $( "#zip" ).next().text("Please enter a valid zip code.");
        }
        if ( dob === "" || !isDate(dob) ) 
        {
            isValid = false;
            $( "#dob" ).next().text(
                "Please enter a valid date in MM/DD/YYYY format.");
        }
        
        //only runs if everything is valid
        if ( isValid ) 
        { 
            // initialize session storage item called profile
            sessionStorage.profile = "";
            
            //adds the items from the profile array to sessionStorage
            for(var index in profile)
            {
                sessionStorage.profile = sessionStorage.profile + index + "=" + profile[index] + "|";
            }	
			
            // go to profile page
            location.href = "profile.html";
        }
        
        $("#email").focus(); 
    });
    
    // set focus on initial load
    $("#email").focus();
});