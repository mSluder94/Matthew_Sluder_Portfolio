$(document).ready(function()
{
    // Runs when the A tags are clicked
    $("a").click(function()
    {
        $(this).toggleClass("hide");
        
        //if the class is hide it shows the next div tag and 
        //changes the link to 'Show Less'
        if($(this).attr("class") == "hide")
        {
            $(this).prev().show();
            $(this).text("Show Less");
        }
        
        //Otherwise the div is hidden and 
        //the link changed to 'Show More'
        else 
        {
            $(this).prev().hide();
            $(this).text("Show More");
        }
        
    });
    
});